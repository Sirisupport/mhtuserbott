# Added for fix restart event
if __name__ == '__main__':
    from userbot import main
